
-- Insert sample products for the e-commerce store
INSERT INTO products (name, description, price, image_url, category, stock_quantity, is_featured) VALUES
('Wireless Bluetooth Headphones', 'Premium noise-canceling headphones with 30-hour battery life', 99.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&h=600&fit=crop', 'Electronics', 50, 1),
('Smart Fitness Watch', 'Track your workouts, heart rate, and sleep with this advanced smartwatch', 249.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&h=600&fit=crop', 'Electronics', 35, 1),
('Organic Cotton T-Shirt', 'Comfortable and sustainable basic tee made from 100% organic cotton', 29.99, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800&h=600&fit=crop', 'Clothing', 100, 0),
('Ceramic Coffee Mug', 'Handcrafted ceramic mug perfect for your morning coffee', 19.99, 'https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?w=800&h=600&fit=crop', 'Home & Kitchen', 75, 0),
('Leather Crossbody Bag', 'Stylish and durable leather bag for everyday use', 89.99, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&h=600&fit=crop', 'Accessories', 25, 1),
('Stainless Steel Water Bottle', 'Insulated water bottle that keeps drinks cold for 24 hours', 34.99, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&h=600&fit=crop', 'Home & Kitchen', 80, 0),
('Gaming Mechanical Keyboard', 'RGB backlit mechanical keyboard with tactile switches', 149.99, 'https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=800&h=600&fit=crop', 'Electronics', 30, 1),
('Yoga Exercise Mat', 'Non-slip yoga mat with alignment lines for better posture', 45.99, 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800&h=600&fit=crop', 'Sports & Fitness', 60, 0),
('Wireless Phone Charger', 'Fast wireless charging pad compatible with all Qi-enabled devices', 39.99, 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=800&h=600&fit=crop', 'Electronics', 45, 0),
('Canvas Sneakers', 'Classic low-top sneakers in white with comfortable rubber sole', 69.99, 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=800&h=600&fit=crop', 'Shoes', 40, 0),
('Bluetooth Portable Speaker', 'Waterproof speaker with 360-degree sound and 12-hour battery', 79.99, 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&h=600&fit=crop', 'Electronics', 55, 1),
('Scented Candle Set', 'Set of 3 soy wax candles with calming lavender, vanilla, and eucalyptus scents', 24.99, 'https://images.unsplash.com/photo-1602874801006-24c7ad659439?w=800&h=600&fit=crop', 'Home & Kitchen', 90, 0),
('Denim Jacket', 'Classic blue denim jacket with a modern fit and vintage wash', 79.99, 'https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=800&h=600&fit=crop', 'Clothing', 30, 0),
('Sunglasses', 'UV protection sunglasses with polarized lenses and lightweight frame', 49.99, 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=800&h=600&fit=crop', 'Accessories', 65, 0),
('Laptop Stand', 'Adjustable aluminum laptop stand for better ergonomics', 59.99, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=800&h=600&fit=crop', 'Office', 40, 0),
('Essential Oils Diffuser', 'Ultrasonic aromatherapy diffuser with color-changing LED lights', 44.99, 'https://images.unsplash.com/photo-1591641822451-8bce3c4d37a3?w=800&h=600&fit=crop', 'Home & Kitchen', 35, 0),
('Running Shoes', 'Lightweight running shoes with breathable mesh and responsive cushioning', 119.99, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&h=600&fit=crop', 'Shoes', 25, 1),
('Smartphone Case', 'Protective phone case with card holder and magnetic closure', 24.99, 'https://images.unsplash.com/photo-1601593346740-925612772716?w=800&h=600&fit=crop', 'Accessories', 100, 0),
('Indoor Plant', 'Low-maintenance succulent plant in decorative ceramic pot', 19.99, 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800&h=600&fit=crop', 'Home & Kitchen', 50, 0),
('Wireless Mouse', 'Ergonomic wireless mouse with precision tracking and long battery life', 29.99, 'https://images.unsplash.com/photo-1527814050087-3793815479db?w=800&h=600&fit=crop', 'Electronics', 70, 0);
