
DELETE FROM products;
