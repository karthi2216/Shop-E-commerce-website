
DROP INDEX idx_cart_product;
DROP INDEX idx_cart_session;
DROP INDEX idx_products_featured;
DROP INDEX idx_products_category;
DROP TABLE cart_items;
DROP TABLE products;
