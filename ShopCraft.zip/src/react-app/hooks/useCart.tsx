import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { CartItemWithProduct } from '@/shared/types';

interface CartContextType {
  items: CartItemWithProduct[];
  loading: boolean;
  error: string | null;
  sessionId: string;
  addToCart: (productId: number, quantity: number) => Promise<void>;
  updateQuantity: (itemId: number, quantity: number) => Promise<void>;
  removeItem: (itemId: number) => Promise<void>;
  totalItems: number;
  totalPrice: number;
  refreshCart: () => Promise<void>;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItemWithProduct[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionId] = useState(() => {
    const stored = localStorage.getItem('session_id');
    if (stored) return stored;
    
    const newSessionId = Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    localStorage.setItem('session_id', newSessionId);
    return newSessionId;
  });

  const fetchCart = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/cart', {
        headers: { 'x-session-id': sessionId }
      });
      
      if (!response.ok) throw new Error('Failed to fetch cart');
      
      const cartItems = await response.json();
      setItems(cartItems);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = async (productId: number, quantity: number = 1) => {
    try {
      setLoading(true);
      const response = await fetch('/api/cart', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': sessionId
        },
        body: JSON.stringify({ product_id: productId, quantity })
      });
      
      if (!response.ok) throw new Error('Failed to add to cart');
      
      await fetchCart();
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (itemId: number, quantity: number) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/cart/${itemId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': sessionId
        },
        body: JSON.stringify({ quantity })
      });
      
      if (!response.ok) throw new Error('Failed to update cart');
      
      await fetchCart();
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const removeItem = async (itemId: number) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/cart/${itemId}`, {
        method: 'DELETE',
        headers: { 'x-session-id': sessionId }
      });
      
      if (!response.ok) throw new Error('Failed to remove item');
      
      await fetchCart();
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [sessionId]);

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  return (
    <CartContext.Provider value={{
      items,
      loading,
      error,
      sessionId,
      addToCart,
      updateQuantity,
      removeItem,
      totalItems,
      totalPrice,
      refreshCart: fetchCart
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
