import { ShoppingCart, Store, Menu } from 'lucide-react';
import { useCart } from '@/react-app/hooks/useCart';
import { useState } from 'react';
import CartDrawer from './CartDrawer';

export default function Header() {
  const { totalItems } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-purple-600 to-blue-600">
                  <Store className="h-5 w-5 text-white" />
                </div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  ShopCraft
                </h1>
              </div>
            </div>

            <nav className="hidden md:flex items-center space-x-6">
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                Home
              </a>
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                Products
              </a>
              <a href="#" className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors">
                Categories
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-gray-700 hover:text-gray-900 transition-colors"
              >
                <ShoppingCart className="h-5 w-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-blue-600 text-xs font-bold text-white">
                    {totalItems}
                  </span>
                )}
              </button>
              
              <button className="md:hidden p-2">
                <Menu className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}
