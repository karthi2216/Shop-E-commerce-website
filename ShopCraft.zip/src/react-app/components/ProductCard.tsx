import { ShoppingCart, Star } from 'lucide-react';
import { Product } from '@/shared/types';
import { useCart } from '@/react-app/hooks/useCart';

interface ProductCardProps {
  product: Product;
  onClick?: () => void;
}

export default function ProductCard({ product, onClick }: ProductCardProps) {
  const { addToCart, loading } = useCart();

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await addToCart(product.id, 1);
  };

  return (
    <div
      onClick={onClick}
      className="group relative overflow-hidden rounded-2xl bg-white shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:scale-[1.02] border border-gray-100"
    >
      {product.is_featured && (
        <div className="absolute top-4 left-4 z-10 flex items-center space-x-1 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 px-3 py-1 text-xs font-bold text-white">
          <Star className="h-3 w-3 fill-current" />
          <span>Featured</span>
        </div>
      )}

      <div className="aspect-[4/3] overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100">
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-gray-400">
            <div className="text-center">
              <div className="text-4xl mb-2">📦</div>
              <p className="text-sm">No Image</p>
            </div>
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="mb-2">
          {product.category && (
            <span className="inline-block rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-600 mb-2">
              {product.category}
            </span>
          )}
          <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-purple-600 transition-colors">
            {product.name}
          </h3>
        </div>

        {product.description && (
          <p className="text-sm text-gray-600 line-clamp-2 mb-4">
            {product.description}
          </p>
        )}

        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-xl font-bold text-gray-900">
              ${product.price.toFixed(2)}
            </span>
            {product.stock_quantity > 0 ? (
              <span className="text-xs text-green-600 font-medium">
                {product.stock_quantity} in stock
              </span>
            ) : (
              <span className="text-xs text-red-600 font-medium">
                Out of stock
              </span>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={loading || product.stock_quantity === 0}
            className="flex items-center space-x-2 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 px-4 py-2 text-sm font-medium text-white shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Add</span>
          </button>
        </div>
      </div>
    </div>
  );
}
