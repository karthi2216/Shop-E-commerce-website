import { BrowserRouter as Router, Routes, Route } from "react-router";
import { CartProvider } from "@/react-app/hooks/useCart";
import Header from "@/react-app/components/Header";
import HomePage from "@/react-app/pages/Home";
import ProductDetail from "@/react-app/pages/ProductDetail";

export default function App() {
  return (
    <CartProvider>
      <Router>
        <div className="min-h-screen">
          <Header />
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/product/:id" element={<ProductDetail />} />
          </Routes>
        </div>
      </Router>
    </CartProvider>
  );
}
