import z from "zod";

export const ProductSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  price: z.number(),
  image_url: z.string().nullable(),
  category: z.string().nullable(),
  stock_quantity: z.number(),
  is_featured: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CartItemSchema = z.object({
  id: z.number(),
  session_id: z.string(),
  product_id: z.number(),
  quantity: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CartItemWithProductSchema = CartItemSchema.extend({
  product: ProductSchema,
});

export const AddToCartSchema = z.object({
  product_id: z.number(),
  quantity: z.number().min(1),
});

export const UpdateCartItemSchema = z.object({
  quantity: z.number().min(0),
});

export type Product = z.infer<typeof ProductSchema>;
export type CartItem = z.infer<typeof CartItemSchema>;
export type CartItemWithProduct = z.infer<typeof CartItemWithProductSchema>;
export type AddToCart = z.infer<typeof AddToCartSchema>;
export type UpdateCartItem = z.infer<typeof UpdateCartItemSchema>;
