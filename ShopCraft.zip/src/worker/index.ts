import { Hono } from "hono";
import { cors } from "hono/cors";
import { 
  ProductSchema, 
  CartItemWithProductSchema, 
  AddToCartSchema, 
  UpdateCartItemSchema 
} from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("*", cors());

// Generate or get session ID from header
function getSessionId(c: any): string {
  const sessionId = c.req.header("x-session-id");
  if (sessionId) return sessionId;
  
  // Generate a simple session ID
  return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
}

// Get all products
app.get("/api/products", async (c) => {
  try {
    const stmt = c.env.DB.prepare("SELECT * FROM products ORDER BY is_featured DESC, created_at DESC");
    const { results } = await stmt.all();
    
    const products = results.map(row => ProductSchema.parse({
      ...row,
      is_featured: Boolean(row.is_featured)
    }));
    
    return c.json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
    return c.json({ error: "Failed to fetch products" }, 500);
  }
});

// Get single product
app.get("/api/products/:id", async (c) => {
  try {
    const id = parseInt(c.req.param("id"));
    const stmt = c.env.DB.prepare("SELECT * FROM products WHERE id = ?");
    const product = await stmt.bind(id).first();
    
    if (!product) {
      return c.json({ error: "Product not found" }, 404);
    }
    
    const parsedProduct = ProductSchema.parse({
      ...product,
      is_featured: Boolean(product.is_featured)
    });
    
    return c.json(parsedProduct);
  } catch (error) {
    console.error("Error fetching product:", error);
    return c.json({ error: "Failed to fetch product" }, 500);
  }
});

// Get cart items
app.get("/api/cart", async (c) => {
  try {
    const sessionId = getSessionId(c);
    
    const stmt = c.env.DB.prepare(`
      SELECT 
        ci.*,
        p.name,
        p.description,
        p.price,
        p.image_url,
        p.category,
        p.stock_quantity,
        p.is_featured,
        p.created_at as product_created_at,
        p.updated_at as product_updated_at
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.session_id = ?
      ORDER BY ci.created_at DESC
    `);
    
    const { results } = await stmt.bind(sessionId).all();
    
    const cartItems = results.map(row => CartItemWithProductSchema.parse({
      id: row.id,
      session_id: row.session_id,
      product_id: row.product_id,
      quantity: row.quantity,
      created_at: row.created_at,
      updated_at: row.updated_at,
      product: {
        id: row.product_id,
        name: row.name,
        description: row.description,
        price: row.price,
        image_url: row.image_url,
        category: row.category,
        stock_quantity: row.stock_quantity,
        is_featured: Boolean(row.is_featured),
        created_at: row.product_created_at,
        updated_at: row.product_updated_at,
      }
    }));
    
    return c.json(cartItems);
  } catch (error) {
    console.error("Error fetching cart:", error);
    return c.json({ error: "Failed to fetch cart" }, 500);
  }
});

// Add item to cart
app.post("/api/cart", async (c) => {
  try {
    const sessionId = getSessionId(c);
    const body = await c.req.json();
    const { product_id, quantity } = AddToCartSchema.parse(body);
    
    // Check if item already exists in cart
    const existingItem = await c.env.DB.prepare(
      "SELECT * FROM cart_items WHERE session_id = ? AND product_id = ?"
    ).bind(sessionId, product_id).first();
    
    if (existingItem) {
      // Update quantity
      await c.env.DB.prepare(
        "UPDATE cart_items SET quantity = quantity + ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(quantity, existingItem.id).run();
    } else {
      // Insert new item
      await c.env.DB.prepare(
        "INSERT INTO cart_items (session_id, product_id, quantity) VALUES (?, ?, ?)"
      ).bind(sessionId, product_id, quantity).run();
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error adding to cart:", error);
    return c.json({ error: "Failed to add to cart" }, 500);
  }
});

// Update cart item quantity
app.put("/api/cart/:id", async (c) => {
  try {
    const id = parseInt(c.req.param("id"));
    const sessionId = getSessionId(c);
    const body = await c.req.json();
    const { quantity } = UpdateCartItemSchema.parse(body);
    
    if (quantity === 0) {
      // Remove item
      await c.env.DB.prepare(
        "DELETE FROM cart_items WHERE id = ? AND session_id = ?"
      ).bind(id, sessionId).run();
    } else {
      // Update quantity
      await c.env.DB.prepare(
        "UPDATE cart_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND session_id = ?"
      ).bind(quantity, id, sessionId).run();
    }
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating cart item:", error);
    return c.json({ error: "Failed to update cart item" }, 500);
  }
});

// Remove item from cart
app.delete("/api/cart/:id", async (c) => {
  try {
    const id = parseInt(c.req.param("id"));
    const sessionId = getSessionId(c);
    
    await c.env.DB.prepare(
      "DELETE FROM cart_items WHERE id = ? AND session_id = ?"
    ).bind(id, sessionId).run();
    
    return c.json({ success: true });
  } catch (error) {
    console.error("Error removing cart item:", error);
    return c.json({ error: "Failed to remove cart item" }, 500);
  }
});

export default app;
